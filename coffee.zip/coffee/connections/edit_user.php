<?php
// Include db.php for the database connection
include 'db.php';

// Retrieve form data
$username = $_POST["username"];
$email = $_POST["email"];
$password = $_POST["password"];
$role = $_POST["role"];

// Check if the password field is empty
if (empty($password)) {
    // Password field is empty, retrieve the existing password from the database
    $query = "SELECT password FROM Users WHERE email = :email";
    $stmt = $pdo->prepare($query);
    $stmt->execute(array(':email' => $email));
    $existingPassword = $stmt->fetchColumn();

    // Use the existing password for updating the record
    $password = $existingPassword;
}

// Update the user record in the database
$query = "UPDATE Users SET username = :username, password = :password, role = :role WHERE email = :email";
$stmt = $pdo->prepare($query);
$stmt->execute(array(':username' => $username, ':password' => $password, ':role' => $role, ':email' => $email));

// Redirect to the manage_user.php page
header("Location: ../pages/manage_user.php");
exit();

?>