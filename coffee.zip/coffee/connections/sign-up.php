<?php
// Include db.php for the database connection
include 'db.php';

// Start the session
session_start();

// Initialize the error message variable
$error_message = '';

// Sign-up form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Validate the form data (you can add more validation as per your requirements)
    if (empty($username) || empty($email) || empty($password)) {
        $error_message = "Please fill in all the fields.";
    } else {
        // Check if the email already exists in the database
        $query = "SELECT COUNT(*) FROM Users WHERE email = :email";
        $stmt = $pdo->prepare($query);
        $stmt->execute(array(':email' => $email));
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            $error_message = "Email already exists. Please use a different email.";
        } else {
            // Perform database query to insert user details
            $query = "INSERT INTO Users (username, email, password, role) VALUES (:username, :email, :password, :role)";
            $stmt = $pdo->prepare($query);
            $role = "User"; // Set the default role for new users
            $stmt->execute(array(':username' => $username, ':email' => $email, ':password' => $password, ':role' => $role));

            // Check if the user was successfully registered
            if ($stmt->rowCount() > 0) {
                $_SESSION['success_message'] = "Sign-up successful!";
                header("Location: ../pages/sign-in.php");
                exit();
                // Perform any additional actions or redirect to the login page
            } else {
                $error_message = "Error occurred. Please try again.";
            }
        }
    }

    // Store the error message in session
    $_SESSION['error_message'] = $error_message;

    // Redirect back to the sign-up page
    header("Location: ../pages/sign-up.php");
    exit();
}

// Retrieve and clear the error message from session, if present
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// ...

?>