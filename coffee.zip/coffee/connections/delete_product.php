<?php
// Include db.php for the database connection
include '../connections/db.php';

// Check if product_id parameter is provided in the POST request
if (isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    // Perform the deletion query
    $query = "DELETE FROM Products WHERE product_id = :product_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['product_id' => $product_id]);

    // Check if the deletion was successful
    if ($stmt->rowCount() > 0) {
        // Deletion successful
        // Redirect back to the inventory page
        header("Location: ../pages/inventory.php");
        exit();
    } else {
        // Deletion failed
        // Display an error message or handle the failure as desired
        echo "Failed to delete the product. Please try again.";
        header("Location: ../pages/inventory.php");
        exit();
    }
} else {
    // Invalid request, product_id parameter is missing
    // Redirect back to the inventory page or show an error message
    header("Location: ../pages/inventory.php");
    exit();
}
?>