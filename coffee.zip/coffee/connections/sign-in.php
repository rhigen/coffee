<?php
// Include db.php for the database connection
include 'db.php';

// Start the session
session_start();

// Sign-in form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Perform database query to check user credentials
    $query = "SELECT * FROM Users WHERE email = :email AND password = :password";
    $stmt = $pdo->prepare($query);
    $stmt->execute(array(':email' => $email, ':password' => $password));

    // Check if the user exists and has valid credentials
    if ($stmt->rowCount() > 0) {
        // User is authenticated
        // Fetch user data
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if the user exists and has valid credentials
        if ($user) {
            // User is authenticated
            // Store user information in session
            $_SESSION['user_email'] = $email;
            $_SESSION['user_id'] = $user['user_id'];

            // Redirect to the index page
            header("Location: ../pages/index.php");
            exit();
        }

    } else {
        // User authentication failed
        $_SESSION['message'] = "Invalid email or password. Please try again.";
        header("Location: ../pages/sign-in.php");
        exit();
    }
}

// Retrieve and clear the error message from session, if present
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}

// ...

?>