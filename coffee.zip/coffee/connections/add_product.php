<?php
// Include db.php for the database connection
include '../connections/db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $productName = $_POST["product_name"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $quantity = $_POST["quantity"];

    // Prepare the SQL statement to insert a new product
    $query = "INSERT INTO Products (product_name, description, price, quantity) VALUES (:product_name, :description, :price, :quantity)";
    $stmt = $pdo->prepare($query);

    // Bind the parameters with the form data
    $stmt->bindParam(':product_name', $productName);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':quantity', $quantity);

    // Execute the SQL statement
    if ($stmt->execute()) {
        // Redirect to the inventory page
        header("Location: ../pages/inventory.php");
        exit();
    } else {
        // Handle the error if the SQL execution fails
        echo "Error occurred. Please try again.";
        header("Location: ../pages/inventory.php");
    }
} else {
    // Redirect back to the add product form if the form is not submitted
    header("Location: ../pages/inventory.php");
    exit();
}
?>