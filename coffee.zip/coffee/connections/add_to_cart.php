<?php
// Assuming you have established a connection to your database
include 'db.php';

// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the product details from the form data
    $productId = $_POST['product_id'];
    $productName = $_POST['product_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $totalPrice = $_POST['tp'];
    $Qtorder = $_POST['order'];

    // Create an array for the order details
    $orderDetails = [
        'product_id' => $productId,
        'product_name' => $productName,
        'description' => $description,
        'price' => $price,
        'quantity1' => $quantity,
        'total_price' => $totalPrice,
        'quantity' => $Qtorder
    ];

    // Store the order details in a session variable
    $_SESSION['order_details'] = $orderDetails;

    // Get the order ID from the session or any other method you use for identifying the current order
    $orderId = $_SESSION['new_transaction_no'];

    // Insert the order details into the OrderDetails table
    $query = "INSERT INTO OrderDetails (order_id, product_id, quantity, price, subtotal) VALUES (?, ?, ?, ?,?)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$orderId, $productId, $Qtorder, $price, $totalPrice]);

    // Update the product quantity in the Products table
    $updateQuery = "UPDATE Products SET quantity = quantity - ? WHERE product_id = ?";
    $updateStmt = $pdo->prepare($updateQuery);
    $updateStmt->execute([$Qtorder, $productId]);

    // Redirect to the next page or perform any other actions
    header("Location: ../pages/order.php");
    exit();
}
?>