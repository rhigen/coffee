<?php
// Include db.php for the database connection
include 'db.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user_id'])) {
    // Retrieve the user_id from the form
    $user_id = $_POST['user_id'];

    // Delete the user from the database
    $query = "DELETE FROM Users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(array(':user_id' => $user_id));
    header("Location: ../pages/manage_user.php");
    exit();
}

// Query to fetch user records from the database
$query = "SELECT * FROM Users";
$stmt = $pdo->query($query);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
header("Location: ../pages/manage_user.php");
exit();
?>