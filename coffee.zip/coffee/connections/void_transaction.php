<?php
// Assuming you have established a connection to your database
include '../connections/db.php';

// Check if the transaction number is provided
if (isset($_POST['transaction_no'])) {
    // Get the transaction number from the AJAX request
    $transactionNo = $_POST['transaction_no'];

    // Retrieve the product details from the OrderDetails table
    $selectOrderDetailsQuery = "SELECT product_id, quantity FROM OrderDetails WHERE order_id = ?";
    $stmt = $pdo->prepare($selectOrderDetailsQuery);
    $stmt->execute([$transactionNo]);
    $orderDetails = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Loop through the order details and update the product quantity in the Products table
    foreach ($orderDetails as $orderDetail) {
        $productId = $orderDetail['product_id'];
        $quantity = $orderDetail['quantity'];

        // Update the product quantity by adding the returned quantity
        $updateQuantityQuery = "UPDATE Products SET quantity = quantity + ? WHERE product_id = ?";
        $stmt = $pdo->prepare($updateQuantityQuery);
        $stmt->execute([$quantity, $productId]);
    }

    // Delete records from OrderDetails table where order_id matches the provided transaction number
    $deleteOrderDetailsQuery = "DELETE FROM OrderDetails WHERE order_id = ?";
    $stmt = $pdo->prepare($deleteOrderDetailsQuery);
    $stmt->execute([$transactionNo]);

    // Delete record from Orders table where order_id matches the provided transaction number
    $deleteOrderQuery = "DELETE FROM Orders WHERE order_id = ?";
    $stmt = $pdo->prepare($deleteOrderQuery);
    $stmt->execute([$transactionNo]);

    // Send a response back to the JavaScript indicating the successful voiding
    echo "success";

} else {
    // Send a response back to the JavaScript indicating an error
    echo "error";
}
?>