<?php
// Include db.php for the database connection
include 'db.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the product ID from the form
    $product_id = $_POST['product_id'];

    // Retrieve the product record from the database
    $query = "SELECT * FROM Products WHERE product_id = :product_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['product_id' => $product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the product record exists
    if ($product) {
        // Get the updated product information from the form
        $product_name = $_POST['product_name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];

        // Update the product record in the database
        $updateQuery = "UPDATE Products SET product_name = :product_name, description = :description, price = :price, quantity = :quantity WHERE product_id = :product_id";
        $updateStmt = $pdo->prepare($updateQuery);
        $updateStmt->execute([
            'product_name' => $product_name,
            'description' => $description,
            'price' => $price,
            'quantity' => $quantity,
            'product_id' => $product_id
        ]);

        // Redirect to the product table page
        header("Location: ../pages/inventory.php");
        exit();
    } else {
        // Product not found, handle the error or redirect to an error page
    }
} else {
    // Redirect to the product table page if accessed directly without form submission
    header("Location: ../pages/inventory.php");
    exit();
}