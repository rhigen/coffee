<?php
// Assuming you have established a connection to your database
include 'db.php';

// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the user ID from the session or any other method you use for identifying the current user
    $userID = $_SESSION['user_id'];

    // Get the total amount and amount paid from the form data
    $totalAmount = $_POST['total_amount'];
    $amountPaid = $_POST['amount_paid'];
    $_SESSION['amount_paid'] = $amountPaid;

    // Calculate the change amount
    $changeAmount = $amountPaid - $totalAmount;

    // Insert the order into the database
    $query = "INSERT INTO Orders (order_id, user_id, order_date, total_amount, amount_paid, change_amount) VALUES (?, ?, CURRENT_TIMESTAMP, ?, ?, ?)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$_SESSION['new_transaction_no'], $userID, $totalAmount, $amountPaid, $changeAmount]);


}

// Redirect to a success page or display a success message
header("Location: ../pages/order.php");
exit();

?>