<?php
// Assuming you have established a connection to your database
include '../connections/db.php';

$query = "SELECT DATE_FORMAT(order_date, '%Y-%m-%d') AS date, SUM(total_amount) AS total_sales FROM Orders GROUP BY date ORDER BY date";
$stmt = $pdo->query($query);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Extract the dates and total sales from the query results
$dates = [];
$totalSales = [];

foreach ($results as $row) {
    $dates[] = $row['date'];
    $totalSales[] = $row['total_sales'];
}

// Prepare the response data
$response = [
    'dates' => $dates,
    'totalSales' => $totalSales
];

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);