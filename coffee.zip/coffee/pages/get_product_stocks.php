<?php
// Assuming you have established a connection to your database
include '../connections/db.php';

$query = "SELECT product_name, quantity FROM products";
$stmt = $pdo->query($query);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Extract the product names and stocks from the query results
$productNames = [];
$productStocks = [];

foreach ($results as $row) {
    $productNames[] = $row['product_name'];
    $productStocks[] = $row['quantity'];
}

// Prepare the response data
$response = [
    'productNames' => $productNames,
    'productStocks' => $productStocks
];

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>