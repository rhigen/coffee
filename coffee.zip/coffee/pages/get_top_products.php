<?php
// Assuming you have established a connection to your database
include '../connections/db.php';

$query = "SELECT od.product_id, COUNT(*) AS order_count, p.product_name 
          FROM orderdetails od
          INNER JOIN products p ON od.product_id = p.product_id 
          GROUP BY od.product_id 
          ORDER BY order_count DESC 
          LIMIT 5";

$stmt = $pdo->query($query);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Extract the product IDs, order counts, and product names from the query results
$productIDs = [];
$orderCounts = [];
$productNames = [];

foreach ($results as $row) {
    $productIDs[] = $row['product_id'];
    $orderCounts[] = $row['order_count'];
    $productNames[] = $row['product_name'];
}

// Prepare the response data
$response = [
    'productIDs' => $productIDs,
    'orderCounts' => $orderCounts,
    'productNames' => $productNames
];

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>