<?php
// Assuming you have established a connection to your database
include '../connections/db.php';

$query = "SELECT u.user_id, u.username, COUNT(*) AS sales_count 
          FROM orders o
          INNER JOIN users u ON o.user_id = u.user_id
          GROUP BY u.user_id
          ORDER BY sales_count DESC
          LIMIT 5";

$stmt = $pdo->query($query);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Extract the user IDs, usernames, and sales counts from the query results
$userIDs = [];
$usernames = [];
$salesCounts = [];

foreach ($results as $row) {
    $userIDs[] = $row['user_id'];
    $usernames[] = $row['username'];
    $salesCounts[] = $row['sales_count'];
}

// Prepare the response data
$response = [
    'userIDs' => $userIDs,
    'usernames' => $usernames,
    'salesCounts' => $salesCounts
];

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);

?>