$(document).ready(function () {
  $.ajax({
    url: "http://localhost/html/chart1.php",
    type: "GET",
    success: function (data) {
      console.log(data);

      var userid = [];
      var facebook_follower = [];
      var twitter_follower = [];
      var googleplus_follower = [];

      for (var i in data) {
        userid.push("UserID " + data[i].userid);
        facebook_follower.push(data[i].facebook);
        twitter_follower.push(data[i].twitter);
        googleplus_follower.push(data[i].googleplus);
      }

      var chartdata = {
        labels: userid,
        datasets: [
          {
            label: "CABATAY",
            fill: false,
            lineTension: 0.1,
            backgroundColor: "BLACK",
            borderColor: "BLACK",
            pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
            pointHoverBorderColor: "BLACK",
            data: facebook_follower,
          },
          {
            label: "DOMINGO_WEAK",
            fill: false,
            lineTension: 0.1,
            backgroundColor: "GREEN",
            borderColor: "GREEN",
            pointHoverBackgroundColor: "rgba(29, 202, 255, 1)",
            pointHoverBorderColor: "rgba(29, 202, 255, 1)",
            data: twitter_follower,
          },
          {
            label: "LUA",
            fill: false,
            lineTension: 0.9,
            backgroundColor: "YELLOW",
            borderColor: "YELLOW",
            pointHoverBackgroundColor: "rgba(211, 72, 54, 1)",
            pointHoverBorderColor: "rgba(211, 72, 54, 1)",
            data: googleplus_follower,
          },
        ],
      };

      var ctx = $("#mycanvas1");

      var LineGraph = new Chart(ctx, {
        type: "line",
        data: chartdata,
      });
    },
    error: function (data) {},
  });
});
