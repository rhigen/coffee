<?php
session_start();

// Include db.php for the database connection
include '../connections/db.php';

// Retrieve the user role from the database based on the session user_id
$query = "SELECT role FROM Users WHERE user_id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the user is a manager or user
if ($user['role'] === 'user') {
    // Redirect back to order.php
    header("Location: ../pages/order.php");
    exit();
}

// Set the 'role' value in the session
$_SESSION['role'] = $user['role'];

// Rest of your code...

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../images/tea.png">
    <title>
        Cafe
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css"
        href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <!-- Nucleo Icons -->
    <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <!-- CSS Files -->
    <link id="pagestyle" href="../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
    <!-- Nepcha Analytics (nepcha.com) -->
    <!-- Nepcha is a easy-to-use web analytics. No cookies and fully compliant with GDPR, CCPA and PECR. -->
    <script defer data-site="YOUR_DOMAIN_HERE" src="https://api.nepcha.com/js/nepcha-analytics.js"></script>
</head>

<body class="g-sidenav-show  bg-gray-200">



    <aside
        class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark"
        id="sidenav-main">
        <div class="sidenav-header">
            <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
                aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-0" href="index.php">
                <img src="../images/tea.png" class="navbar-brand-img h-100" alt="main_logo">
                <span class="ms-1 font-weight-bold text-white">Cafe Mgment System</span>
            </a>
        </div>
        <hr class="horizontal light mt-0 mb-2">
        <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
            <ul class="navbar-nav">
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'manager'): ?>
                    <li class="nav-item">
                        <a class="nav-link text-white active bg-gradient-primary" href="index.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">dashboard</i>
                            </div>
                            <span class="nav-link-text ms-1">Dashboard</span>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="nav-item">
                    <?php if (isset($_SESSION['role']) && ($_SESSION['role'] === 'manager' || $_SESSION['role'] === 'admin')): ?>

                        <a class="nav-link text-white" href="inventory.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">table_view</i>
                            </div>
                            <span class="nav-link-text ms-1">Inventory</span>
                        </a>
                    <?php endif; ?>
                </li>


                <li class="nav-item">
                    <a class="nav-link text-white " href="order.php">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">receipt_long</i>
                        </div>
                        <span class="nav-link-text ms-1">Order</span>
                    </a>
                </li>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'manager'): ?>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="history.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">view_in_ar</i>
                            </div>
                            <span class="nav-link-text ms-1">History</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <li class="nav-item mt-3">
                        <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages
                        </h6>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="manage_user.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">person</i>
                            </div>
                            <span class="nav-link-text ms-1">Manage User</span>
                        </a>
                    </li>
                <?php endif; ?>



            </ul>
        </div>
    </aside>






    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

        <!-- Navbar -->
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur"
            data-scroll="true">
            <div class="container-fluid py-1 px-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
                        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a>
                        </li>
                        <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Dashboard</li>
                    </ol>
                    <h6 class="font-weight-bolder mb-0">Dashboard</h6>
                </nav>
                <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
                    <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                        <div class="input-group input-group-outline">
                            <label class="form-label">Type here...</label>
                            <input type="text" class="form-control">
                        </div>
                    </div>

                    </li>
                    <li class="nav-item d-flex align-items-center">
                        <a href="sign-in.php" class="nav-link text-body font-weight-bold px-0">
                            <i class="fa fa-user me-sm-1"></i>
                            <span class="d-sm-inline d-none">Log out</span>
                        </a>
                    </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="container-fluid py-4">






            <div class="row mt-4">
                <div class="col-lg-4 col-md-6 mt-4 mb-4">
                    <div class="card z-index-2 ">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                            <div class="bg-gradient-primary shadow-primary border-radius-lg py-3 pe-1">
                                <div class="chart">
                                    <canvas id="chart-bars1" class="chart-canvas" height="170"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <h6 class="mb-0">Total Sales</h6>
                            <p class="text-sm">Overall Sales for the year</p>
                            <hr class="dark horizontal">
                            <div class="d-flex">
                                <i class="material-icons text-sm my-auto me-1">schedule</i>
                                <p class="mb-0 text-sm" id="total-sales">Just updated</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-4 mb-4">
                    <div class="card z-index-2  ">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                            <div class="bg-gradient-success shadow-success border-radius-lg py-3 pe-1">
                                <div class="chart">
                                    <canvas id="chart-bars2" class="chart-canvas" height="170"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <h6 class="mb-0 "> Total Revenue </h6>
                            <p class="text-sm "> (<span class="font-weight-bolder">+15%</span>) increase in today sales.
                            </p>
                            <hr class="dark horizontal">
                            <div class="d-flex ">
                                <i class="material-icons text-sm my-auto me-1">schedule</i>
                                <p class="mb-0 text-sm"> updated 4 min ago </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mt-4 mb-3">
                    <div class="card z-index-2 ">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                            <div class="bg-gradient-dark shadow-dark border-radius-lg py-3 pe-1">
                                <div class="chart">
                                    <canvas id="chart-bars3" class="chart-canvas" height="170"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <h6 class="mb-0 ">Top Users</h6>
                            <p class="text-sm ">Overall performance</p>
                            <hr class="dark horizontal">
                            <div class="d-flex ">
                                <i class="material-icons text-sm my-auto me-1">schedule</i>
                                <p class="mb-0 text-sm">just updated</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-lg-6 col-md-6 mt-4 mb-10">
                    <div class="card z-index-2 ">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                            <div class="bg-gradient-success shadow-primary border-radius-lg py-3 pe-1">
                                <div class="chart">
                                    <canvas id="chart-bars4" class="chart-canvas" height="300"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <h6 class="mb-0">Top Products</h6>
                            <p class="text-sm">Best Sellers</p>
                            <hr class="dark horizontal">
                            <div class="d-flex">
                                <i class="material-icons text-sm my-auto me-1">schedule</i>
                                <p class="mb-0 text-sm">just updated</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 mt-4 mb-10">
                    <div class="card z-index-2 ">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                            <div class="bg-gradient-primary shadow-primary border-radius-lg py-3 pe-1">
                                <div class="chart">
                                    <canvas id="chart-bars5" class="chart-canvas" height="300"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <h6 class="mb-0">Stocks</h6>
                            <p class="text-sm">See Stocks</p>
                            <hr class="dark horizontal">
                            <div class="d-flex">
                                <i class="material-icons text-sm my-auto me-1">schedule</i>
                                <p class="mb-0 text-sm">just updated</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>
        </div>
    </main>

    <script src="chart.min.js"></script>
    <script src="jquery.min.js"></script>
    <!--   Core JS Files   -->
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/chartjs.min.js"></script>


    <script>
        // Make an AJAX request to fetch the sales data from the server
        $.ajax({
            url: "get_sales_data.php",
            type: "GET",
            dataType: "json",
            success: function (response) {
                // Extract the data from the response
                var dates = response.dates;
                var totalSales = response.totalSales;

                // Create the chart
                var ctx = document.getElementById("chart-bars1").getContext("2d");
                var chart = new Chart(ctx, {
                    type: "bar",
                    data: {
                        labels: dates,
                        datasets: [{
                            label: "Sales",
                            backgroundColor: "white",
                            borderColor: "rgba(54, 162, 235, 1)",
                            borderWidth: 1,
                            data: totalSales,
                            maxBarThickness: 25
                        }],
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: true,
                                onClick: function (event, legendItem) {
                                    var index = legendItem.datasetIndex;
                                    var meta = chart.getDatasetMeta(index);
                                    meta.hidden = meta.hidden === null ? !chart.data.datasets[index].hidden : null;
                                    chart.update();
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {
                                    color: "rgba(0, 0, 0, 0.05)",
                                    drawBorder: false,
                                    display: true
                                },
                                ticks: {
                                    color: "white",
                                    font: {
                                        size: 12,
                                        weight: "bold"
                                    }
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                },
                                ticks: {
                                    color: "white",
                                    font: {
                                        size: 12,
                                        weight: "bold"
                                    }
                                }
                            }
                        }
                    }
                });

                // Update the legend color to white
                Chart.defaults.color = "#fff";
            },
            error: function (error) {
                console.log(error);
            }
        });
    </script>
    <script>
        // Make an AJAX request to fetch the sales data from the server
        $.ajax({
            url: "get_sales_data.php",
            type: "GET",
            dataType: "json",
            success: function (response) {
                // Extract the data from the response
                var dates = response.dates;
                var totalSales = response.totalSales;



                // Create the chart
                var ctx = document.getElementById("chart-bars2").getContext("2d");
                new Chart(ctx, {
                    type: "line",
                    data: {
                        labels: dates,
                        datasets: [{
                            label: "Sales",
                            tension: 0.4,
                            borderWidth: 0,
                            borderRadius: 4,
                            borderSkipped: false,
                            backgroundColor: "rgba(255, 255, 255, .8)",
                            borderColor: "rgba(255, 255, 255, .8)",
                            borderWidth: 2,
                            pointRadius: 0,
                            data: totalSales,
                            maxBarThickness: 6
                        }],
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            title: {
                                display: true,
                                text: "Revenue",
                                padding: {
                                    top: 10,
                                    bottom: 30
                                },
                                onClick: function (event, legendItem) {
                                    var index = legendItem.datasetIndex;
                                    var meta = chart.getDatasetMeta(index);
                                    meta.hidden = meta.hidden === null ? !chart.data.datasets[index].hidden : null;
                                    chart.update();
                                }
                            },
                            legend: {
                                display: false
                            }
                        },
                        interaction: {
                            intersect: false,
                            mode: 'index',
                        },
                        scales: {
                            y: {
                                grid: {
                                    drawBorder: false,
                                    display: true,
                                    drawOnChartArea: true,
                                    drawTicks: false,
                                    borderDash: [5, 5],
                                    color: 'rgba(255, 255, 255, .2)'
                                },
                                ticks: {
                                    suggestedMin: 0,
                                    suggestedMax: 500,
                                    beginAtZero: true,
                                    padding: 10,
                                    font: {
                                        size: 14,
                                        weight: 300,
                                        family: "Roboto",
                                        style: 'normal',
                                        lineHeight: 2
                                    },
                                    color: "#fff"
                                },
                            },
                            x: {
                                grid: {
                                    drawBorder: false,
                                    display: true,
                                    drawOnChartArea: true,
                                    drawTicks: false,
                                    borderDash: [5, 5],
                                    color: 'rgba(255, 255, 255, .2)'
                                },
                                ticks: {
                                    display: true,
                                    color: '#f8f9fa',
                                    padding: 10,
                                    font: {
                                        size: 14,
                                        weight: 300,
                                        family: "Roboto",
                                        style: 'normal',
                                        lineHeight: 2
                                    },
                                }
                            },
                        },
                    },
                });
            },
            error: function (error) {
                console.log(error);
            }
        });
    </script>
    <script>
        $.ajax({
            url: "get_sales_per_user.php",
            type: "GET",
            dataType: "json",
            success: function (response) {
                var userIDs = response.userIDs;
                var usernames = response.usernames;
                var salesCounts = response.salesCounts;

                // Create the chart
                var ctx = document.getElementById("chart-bars3").getContext("2d");
                new Chart(ctx, {
                    type: "bar",
                    data: {
                        labels: usernames,
                        datasets: [{
                            label: "Sales",
                            backgroundColor: "green",
                            borderColor: "rgba(75, 192, 192, 1)",
                            borderWidth: 1,
                            borderRadius: 8, // Add border radius
                            data: salesCounts,
                            maxBarThickness: 4 // Make the bars thinner
                        }],
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {
                                    color: "rgba(0, 0, 0, 0.05)",
                                    drawBorder: false,
                                    display: true
                                },
                                ticks: {
                                    color: "white",
                                    font: {
                                        size: 12,
                                        weight: "bold"
                                    }
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                },
                                ticks: {
                                    color: "white",
                                    font: {
                                        size: 12,
                                        weight: "bold"
                                    }
                                }
                            }
                        }
                    }
                });
            },
            error: function (error) {
                console.log(error);
            }
        });

    </script>

    <script>
        $.ajax({
            url: "get_top_products.php",
            type: "GET",
            dataType: "json",
            success: function (response) {
                var productIDs = response.productIDs;
                var orderCounts = response.orderCounts;
                var productNames = response.productNames;

                // Create the chart
                var ctx = document.getElementById("chart-bars4").getContext("2d");
                new Chart(ctx, {
                    type: "pie",
                    data: {
                        labels: productNames,
                        datasets: [{
                            label: "Order Count",
                            data: orderCounts,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.8)',
                                'rgba(54, 162, 235, 0.8)',
                                'rgba(255, 206, 86, 0.8)',
                                'rgba(75, 192, 192, 0.8)',
                                'rgba(153, 102, 255, 0.8)'
                            ],
                            borderWidth: 0,
                            borderRadius: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: true,
                                position: 'right'
                            }
                        }
                    }
                });
            },
            error: function (error) {
                console.log(error);
            }
        });
    </script>
    <script>
        $.ajax({
            url: "get_product_stocks.php",
            type: "GET",
            dataType: "json",
            success: function (response) {
                var productNames = response.productNames;
                var productStocks = response.productStocks;

                // Create the chart
                var ctx = document.getElementById("chart-bars5").getContext("2d");
                var chart = new Chart(ctx, {
                    type: "polarArea",
                    data: {
                        labels: productNames,
                        datasets: [{
                            label: "Stocks",
                            data: productStocks,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.8)',
                                'rgba(54, 162, 235, 0.8)',
                                'rgba(255, 206, 86, 0.8)',
                                'rgba(75, 192, 192, 0.8)',
                                'rgba(153, 102, 255, 0.8)'
                            ],
                            borderWidth: 0,
                            borderRadius: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            title: {
                                display: true,
                                text: "Product Stocks",
                                padding: 10,
                                font: {
                                    size: 16,
                                    weight: "bold"
                                }
                            },
                            legend: {
                                display: false
                            }
                        },
                        onClick: function (event, legendItem) {
                            var activePoints = chart.getElementsAtEventForMode(event, 'nearest', { intersect: true });
                            if (activePoints.length > 0) {
                                var index = activePoints[0].index;
                                var productName = chart.data.labels[index];
                                var stock = chart.data.datasets[0].data[index];
                                console.log("Clicked on " + productName + " with stock: " + stock);
                            }
                        }
                    }
                });
            },
            error: function (error) {
                console.log(error);
            }
        });

    </script>


    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/material-dashboard.min.js?v=3.1.0"></script>
</body>

</html>