<?php
session_start();

// Include db.php for the database connection
include '../connections/db.php';

// Retrieve the user role from the database based on the session user_id
$query = "SELECT role, username FROM Users WHERE user_id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the user is a manager or user
if ($user['role'] === 'user') {
    // Redirect back to order.php
    header("Location: ../pages/order.php");
    exit();
}

// Set the 'role' value in the session
$_SESSION['role'] = $user['role'];
$_SESSION['username'] = $user['username'];

// Rest of your code...

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../images/tea.png">
    <title>
        Cafe
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css"
        href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <!-- Nucleo Icons -->
    <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <!-- CSS Files -->
    <link id="pagestyle" href="../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
    <!-- Nepcha Analytics (nepcha.com) -->
    <!-- Nepcha is a easy-to-use web analytics. No cookies and fully compliant with GDPR, CCPA and PECR. -->
    <script defer data-site="YOUR_DOMAIN_HERE" src="https://api.nepcha.com/js/nepcha-analytics.js"></script>
</head>

<body class="g-sidenav-show  bg-gray-200">



    <aside
        class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark"
        id="sidenav-main">
        <div class="sidenav-header">
            <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
                aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-0" href="index.php">
                <img src="../images/tea.png" class="navbar-brand-img h-100" alt="main_logo">
                <span class="ms-1 font-weight-bold text-white">Cafe Mgment System</span>
            </a>
        </div>
        <hr class="horizontal light mt-0 mb-2">
        <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
            <ul class="navbar-nav">
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'manager'): ?>
                    <li class="nav-item">
                        <a class="nav-link text-white " href="index.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">dashboard</i>
                            </div>
                            <span class="nav-link-text ms-1">Dashboard</span>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="nav-item">
                    <?php if (isset($_SESSION['role']) && ($_SESSION['role'] === 'manager' || $_SESSION['role'] === 'admin')): ?>

                        <a class="nav-link text-white " href="inventory.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">table_view</i>
                            </div>
                            <span class="nav-link-text ms-1">Inventory</span>
                        </a>
                    <?php endif; ?>
                </li>


                <li class="nav-item">
                    <a class="nav-link text-white active bg-gradient-primary  " href="order.php">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">receipt_long</i>
                        </div>
                        <span class="nav-link-text ms-1">Order</span>
                    </a>
                </li>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'manager'): ?>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="history.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">view_in_ar</i>
                            </div>
                            <span class="nav-link-text ms-1">History</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <li class="nav-item mt-3">
                        <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages
                        </h6>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="manage_user.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">person</i>
                            </div>
                            <span class="nav-link-text ms-1">Manage User</span>
                        </a>
                    </li>
                <?php endif; ?>



            </ul>
        </div>
    </aside>






    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

        <!-- Navbar -->
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur"
            data-scroll="true">
            <div class="container-fluid py-1 px-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
                        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a>
                        </li>
                        <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Order</li>
                    </ol>
                    <h6 class="font-weight-bolder mb-0">Order</h6>
                </nav>
                <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
                    <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                        <div class="input-group input-group-outline">
                            <label class="form-label">Type here...</label>
                            <input type="text" class="form-control">
                        </div>
                    </div>

                    </li>
                    <li class="nav-item d-flex align-items-center">
                        <a href="sign-in.php" class="nav-link text-body font-weight-bold px-0">
                            <i class="fa fa-user me-sm-1"></i>
                            <span class="d-sm-inline d-none">Log out</span>
                        </a>
                    </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="container-fluid py-4">

            <div class="row">
                <div class="col-12">

                    <!-- add to cart/receipt -->
                    <div class="card my-4">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">

                            <div
                                class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3 d-flex justify-content-between align-items-center">
                                <h6 class="text-white text-capitalize ps-3">Edit Product</h6>
                            </div>
                        </div>

                        <div class="card-body px-4 pb-3">
                            <div class="row g-3">
                                <form class="row g-3" action="../connections/add_to_cart.php" method="POST">
                                    <div class="col-md-1">
                                        <label for="product-id" class="form-label">PID</label>
                                        <div class="input-group input-group-outline my-3">
                                            <input type="text" class="form-control" id="product-id" name="product_id"
                                                readonly>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="product-name" class="form-label">Product Name</label>
                                        <div class="input-group input-group-outline my-3 border-primary">
                                            <select class="form-select" id="product-name" name="product_name" required
                                                onchange="updateProductInfo()">
                                                <option value="" disabled selected>Select Product Name</option>
                                                <?php
                                                // Query to fetch the product names and details from the database
                                                $query = "SELECT product_id, product_name, description, price, quantity FROM Products";
                                                $stmt = $pdo->query($query);
                                                $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                                // Assuming you have established a connection to your database
                                                include '../connections/db.php';

                                                // Retrieve the order details from the Orders and Products tables
                                                $query = "SELECT p.product_name, o.quantity, o.price, o.subtotal
                                                FROM OrderDetails o
                                                INNER JOIN Products p ON o.product_id = p.product_id
                                                WHERE o.order_id = ?";

                                                $stmt = $pdo->prepare($query);
                                                $stmt->execute([$newTransactionNo]);
                                                $orderDetails = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                                // Store the product names from order details in an array
                                                $orderProductNames = array();
                                                foreach ($orderDetails as $orderDetail) {
                                                    $orderProductNames[] = $orderDetail['product_name'];
                                                }

                                                // Generate the options for the select input
                                                foreach ($products as $product) {
                                                    $productId = $product['product_id'];
                                                    $productName = $product['product_name'];
                                                    $description = $product['description'];
                                                    $price = $product['price'];
                                                    $quantity = $product['quantity'];

                                                    // Check if the product is already in the order details table
                                                    if (!in_array($productName, $orderProductNames)) {
                                                        echo "<option value=\"$productName\" data-product-id=\"$productId\" data-description=\"$description\" data-price=\"$price\" data-quantity=\"$quantity\">$productName</option>";
                                                    }
                                                }
                                                ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">

                                        <label for="description" class="form-label">Description</label>
                                        <div class="input-group input-group-outline my-3 bg-">
                                            <input type="text" class="form-control" id="description" name="description"
                                                readonly>
                                        </div>
                                    </div>

                                    <div class="col-md-1">
                                        <label for="price" class="form-label">Price</label>
                                        <div class="input-group input-group-outline my-3">
                                            <input type="number" class="form-control" id="price" name="price"
                                                step="0.01" readonly>
                                        </div>

                                    </div>
                                    <div class="col-md-1">
                                        <label for="quantity" class="form-label">Stock</label>
                                        <div class="input-group input-group-outline my-3">
                                            <input type="number" class="form-control" id="quantity" name="quantity"
                                                readonly>

                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="quantity" class="form-label">Quantity to Order</label>
                                        <div class="input-group input-group-outline my-3">
                                            <input type="number" class="form-control" id="order" name="order"
                                                oninput="calculateTotalPrice()" max="">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="quantity" class="form-label"> Total Price</label>
                                        <div class="input-group input-group-outline my-3">
                                            <input type="number" class="form-control" id="tp" name="tp" readonly>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="input-group input-group-outline my-3  border-primary ">
                                            <button type="sumbit" class="btn btn-primary" id="add-to-cart-btn"
                                                disabled>Add to cart</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <br>
            <br>

            <div class="col-12">
                <form class="row g-3" action="../connections/save_generate.php" method="POST" id="receipt-form"
                    onsubmit="printAndSubmit(event)">
                    <div class="card my-1">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                            <div
                                class="bg-gradient-success shadow-primary border-radius-lg pt-4 pb-3 d-flex align-items-center">
                                <h6 class="text-white text-capitalize ps-3">Receipt</h6>
                                <button type="button" class="btn btn-danger btn-sm ms-auto" style="margin-right: 20px;"
                                    onclick="confirmVoid()">Void</button>

                            </div>


                        </div>


                        <div class=" card-body px-4 pb-3" id="receipt-table">
                            <h5>Receipt Details</h5>

                            <?php
                            // Assuming you have established a connection to your database
                            include '../connections/db.php';

                            // Query to get the last transaction number
                            $query = "SELECT MAX(order_id) AS last_transaction_no FROM `orders`";
                            $stmt = $pdo->query($query);
                            $result = $stmt->fetch(PDO::FETCH_ASSOC);

                            // Extract the last transaction number and increment it by 1
                            $lastTransactionNo = $result['last_transaction_no'];
                            $newTransactionNo = $lastTransactionNo + 1;

                            // Store the new transaction number in a session variable
                            $_SESSION['new_transaction_no'] = $newTransactionNo;

                            // Echo the new transaction number
                            echo "Transaction No: " . $newTransactionNo;
                            ?>

                            <p>Cashier:
                                <?php echo $_SESSION['username'] ?>
                            </p>
                            <p>Date:
                                <?php echo date("Y-m-d H:i:s"); ?>
                            </p>

                            <table class="table">
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Subtotal</th>
                                </tr>

                                <tbody>

                                    <?php
                                    // Assuming you have established a connection to your database
                                    include '../connections/db.php';

                                    // Retrieve the order details from the Orders and Products tables
                                    $query = "SELECT p.product_name, o.quantity, o.price, o.subtotal
                                    FROM OrderDetails o
                                    INNER JOIN Products p ON o.product_id = p.product_id
                                    WHERE o.order_id = ?";

                                    $stmt = $pdo->prepare($query);
                                    $stmt->execute([$newTransactionNo]);
                                    $orderDetails = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                    // Display the order details in the table
                                    foreach ($orderDetails as $orderDetail) {
                                        echo "<tr>";
                                        echo "<td>" . $orderDetail['product_name'] . "</td>";
                                        echo "<td>" . $orderDetail['quantity'] . "</td>";
                                        echo "<td>₱" . $orderDetail['price'] . "</td>";
                                        echo "<td>₱" . $orderDetail['subtotal'] . "</td>";
                                        echo "</tr>";
                                    }
                                    // Calculate the total amount
                                    $totalAmount = 0;

                                    foreach ($orderDetails as $orderDetail) {
                                        $subtotal = $orderDetail['subtotal'];
                                        $totalAmount += $subtotal;
                                    }


                                    ?>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3">Total</td>
                                        <td id="total-amount">
                                            ₱
                                            <?php echo number_format($totalAmount, 2); ?>
                                            <input type="hidden" name="total_amount"
                                                value="<?php echo $totalAmount; ?>">
                                        </td>

                                    </tr>

                                    <tr>
                                        <td colspan="3">Amount Paid</td>
                                        <td>
                                            <input type="number" class="form-control" id="amount-paid"
                                                name="amount_paid" oninput="updateChange()" step="0.01"
                                                placeholder="<?php echo isset($_POST['amount_paid']) ? $_POST['amount_paid'] : 'Input payment amount here'; ?>"
                                                value="<?php echo isset($_POST['amount_paid']) ? $_POST['amount_paid'] : ''; ?>">



                                        </td>
                                    </tr>

                                    <tr>
                                        <td colspan=" 3">Change
                                        </td>
                                        <td id="change-amount"></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>


                    </div>
                    <div class="input-group input-group-outline my-3 border-primary">
                        <button type="submit" class="btn btn-primary" id="save-generate-btn" disabled>Save and
                            Generate</button>
                    </div>
                </form>
            </div>




    </main>
    <!--   Core JS Files   -->
    <script src=" ../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/chartjs.min.js"></script>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <script>
        function updateProductInfo() {
            const selectElement = document.getElementById("product-name");
            const productIdElement = document.getElementById("product-id");
            const descriptionElement = document.getElementById("description");
            const priceElement = document.getElementById("price");
            const quantityElement = document.getElementById("quantity");
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            const productId = selectedOption.getAttribute("data-product-id");
            const description = selectedOption.getAttribute("data-description");
            const price = selectedOption.getAttribute("data-price");
            const quantity = selectedOption.getAttribute("data-quantity");
            productIdElement.value = productId;
            descriptionElement.value = description;
            priceElement.value = price;
            quantityElement.value = quantity;
        }
    </script>
    <script>
        function calculateTotalPrice() {
            var orderQuantity = parseFloat(document.getElementById("order").value);
            var stockQuantity = parseFloat(document.getElementById("quantity").value);
            var price = parseFloat(document.getElementById("price").value);
            var totalPrice = orderQuantity * price;
            document.getElementById("tp").value = totalPrice.toFixed(2);

            var addToCartButton = document.getElementById("add-to-cart-btn");
            if (orderQuantity > stockQuantity) {
                addToCartButton.disabled = true;
                alert("Quantity exceeded stock!");
            }
            else if (isNaN(orderQuantity)) {
                addToCartButton.disabled = true;
            }
            else {
                addToCartButton.disabled = false;
            }
        }
    </script>

    <script>
        function confirmVoid() {
            if (confirm("Are you sure you want to void this transaction?")) {
                // User clicked "Yes" - perform void operation
                voidTransaction();
            } else {
                // User clicked "No" - do nothing
                event.preventDefault();
            }
        }

        function voidTransaction() {
            // Perform AJAX request to void_transaction.php
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "../connections/void_transaction.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var response = xhr.responseText;
                    if (response === "success") {
                        // Void operation successful
                        window.location.href = 'order.php';
                    }
                }
            };
            xhr.send("transaction_no=" + <?php echo $newTransactionNo; ?>);
        }

        window.addEventListener("DOMContentLoaded", function () {
            // Reset the placeholder to the default value on page reload
            const amountPaidInput = document.getElementById("amount-paid");
            amountPaidInput.setAttribute("placeholder", "Input payment amount here");
        });

        function updateChange() {
            const totalAmount = parseFloat(document.getElementById("total-amount").textContent.replace("₱", ""));
            const amountPaidInput = document.getElementById("amount-paid");
            const amountPaid = parseFloat(amountPaidInput.value);

            // Update the placeholder based on the input value
            const placeholder = amountPaid ? amountPaid.toFixed(2) : "<?php echo isset($_SESSION['amount_paid']) ? $_SESSION['amount_paid'] : 'Input payment amount here'; ?>";
            amountPaidInput.setAttribute("placeholder", placeholder);

            const changeAmount = amountPaid - totalAmount;

            document.getElementById("change-amount").textContent = "₱" + changeAmount.toFixed(2);

            // Enable or disable the "Save and Generate" button based on the change amount
            const saveButton = document.getElementById("save-generate-btn");
            if (changeAmount >= 0) {
                saveButton.disabled = false;
            } else {
                saveButton.disabled = true;
            }
        }

        function addToCart() {
            // Get the selected product details
            const productId = document.getElementById("product-name").value;
            const productName = document.getElementById("product-name").options[document.getElementById("product-name").selectedIndex].text;
            const description = document.getElementById("description").value;
            const price = parseFloat(document.getElementById("price").value);
            const quantity = parseInt(document.getElementById("order").value);
            const totalPrice = parseFloat(document.getElementById("tp").value);

            // Create a new row for the receipt
            const newRow = document.createElement("tr");

            // Create columns for the receipt data
            const productCol = document.createElement("td");
            productCol.textContent = productName;

            const quantityCol = document.createElement("td");
            quantityCol.textContent = quantity;

            const priceCol = document.createElement("td");
            priceCol.textContent = "₱" + price.toFixed(2); // Format price to two decimal places

            const subtotalCol = document.createElement("td");
            subtotalCol.classList.add("subtotal");
            subtotalCol.textContent = "₱" + (price * quantity).toFixed(2); // Calculate and format subtotal

            // Append columns to the new row
            newRow.appendChild(productCol);
            newRow.appendChild(quantityCol);
            newRow.appendChild(priceCol);
            newRow.appendChild(subtotalCol);

            // Append the new row to the receipt tbody
            const receiptProducts = document.getElementById("receipt-products");
            receiptProducts.appendChild(newRow);

            // Clear the form fields
            document.getElementById("product-id").value = "";
            document.getElementById("product-name").selectedIndex = 0;
            document.getElementById("description").value = "";
            document.getElementById("price").value = "";
            document.getElementById("quantity").value = "";
            document.getElementById("order").value = "";
            document.getElementById("tp").value = "";

            updateChange();
        }
    </script>
    <script>
        function printAndSubmit(event) {

            // Submit the form
            event.target.submit();

            event.preventDefault(); // Prevent form submission

            // Create a new window or iframe
            var printWindow = window.open('', '_blank');

            // Build the table HTML content with CSS styles
            var tableContent = `
            <html>
            <head>
                <title>Print Receipt</title>
                <style>
                    table {
                        width: 100%;
                        border-collapse: collapse;
                    }
                    th, td {
                        border: 1px solid #ddd;
                        padding: 8px;
                    }
                    th {
                        background-color: #f2f2f2;
                    }
                    tfoot td {
                        font-weight: bold;
                    }
                </style>
            </head>
            <body>
                ${document.getElementById('receipt-table').outerHTML}
            </body>
            </html>
        `;

            // Set the content of the new window or iframe to the table HTML
            printWindow.document.open();
            printWindow.document.write(tableContent);
            printWindow.document.close();

            // Print the new window or iframe
            printWindow.print();


        }
    </script>







    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/material-dashboard.min.js?v=3.1.0"></script>
</body>

</html>