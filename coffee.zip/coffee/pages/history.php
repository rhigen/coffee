<?php
session_start();

// Include db.php for the database connection
include '../connections/db.php';

// Retrieve the user role from the database based on the session user_id
$query = "SELECT role FROM Users WHERE user_id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the user is a manager or user
if ($user['role'] === 'user') {
    // Redirect back to order.php
    header("Location: ../pages/order.php");
    exit();
}

// Set the 'role' value in the session
$_SESSION['role'] = $user['role'];

// Rest of your code...

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../images/tea.png">
    <title>
        Cafe
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css"
        href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <!-- Nucleo Icons -->
    <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <!-- CSS Files -->
    <link id="pagestyle" href="../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
    <!-- Nepcha Analytics (nepcha.com) -->
    <!-- Nepcha is a easy-to-use web analytics. No cookies and fully compliant with GDPR, CCPA and PECR. -->
    <script defer data-site="YOUR_DOMAIN_HERE" src="https://api.nepcha.com/js/nepcha-analytics.js"></script>
</head>

<body class="g-sidenav-show  bg-gray-200">



    <aside
        class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark"
        id="sidenav-main">
        <div class="sidenav-header">
            <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
                aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-0" href="index.php">
                <img src="../images/tea.png" class="navbar-brand-img h-100" alt="main_logo">
                <span class="ms-1 font-weight-bold text-white">Cafe Mgment System</span>
            </a>
        </div>
        <hr class="horizontal light mt-0 mb-2">
        <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
            <ul class="navbar-nav">
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'manager'): ?>
                    <li class="nav-item">
                        <a class="nav-link text-white " href="index.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">dashboard</i>
                            </div>
                            <span class="nav-link-text ms-1">Dashboard</span>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="nav-item">
                    <?php if (isset($_SESSION['role']) && ($_SESSION['role'] === 'manager' || $_SESSION['role'] === 'admin')): ?>

                        <a class="nav-link text-white " href="inventory.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">table_view</i>
                            </div>
                            <span class="nav-link-text ms-1">Inventory</span>
                        </a>
                    <?php endif; ?>
                </li>


                <li class="nav-item">
                    <a class="nav-link text-white " href="order.php">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">receipt_long</i>
                        </div>
                        <span class="nav-link-text ms-1">Order</span>
                    </a>
                </li>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'manager'): ?>
                    <li class="nav-item">
                        <a class="nav-link text-white active bg-gradient-primary" href="history.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">view_in_ar</i>
                            </div>
                            <span class="nav-link-text ms-1">History</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <li class="nav-item mt-3">
                        <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages
                        </h6>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="manage_user.php">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">person</i>
                            </div>
                            <span class="nav-link-text ms-1">Manage User</span>
                        </a>
                    </li>
                <?php endif; ?>



            </ul>
        </div>
    </aside>






    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

        <!-- Navbar -->
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur"
            data-scroll="true">
            <div class="container-fluid py-1 px-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
                        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a>
                        </li>
                        <li class="breadcrumb-item text-sm text-dark active" aria-current="page">History</li>
                    </ol>
                    <h6 class="font-weight-bolder mb-0">History</h6>
                </nav>
                <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
                    <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                        <div class="input-group input-group-outline">
                            <label class="form-label">Type here...</label>
                            <input type="text" class="form-control">
                        </div>
                    </div>

                    </li>
                    <li class="nav-item d-flex align-items-center">
                        <a href="sign-in.php" class="nav-link text-body font-weight-bold px-0">
                            <i class="fa fa-user me-sm-1"></i>
                            <span class="d-sm-inline d-none">Log out</span>
                        </a>
                    </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="container-fluid py-4">
            <?php
            // Include db.php for the database connection
            include '../connections/db.php';

            // Query to fetch order history records from the database
            $query = "SELECT o.order_id, o.order_date, o.total_amount, o.amount_paid, o.change_amount,
                GROUP_CONCAT(p.product_name SEPARATOR ', ') AS products
            FROM orders o
            INNER JOIN orderdetails od ON o.order_id = od.order_id
            INNER JOIN products p ON od.product_id = p.product_id
            GROUP BY o.order_id
            ORDER BY o.order_id DESC";

            $stmt = $pdo->query($query);
            $orderHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);
            ?>

            <div class="row">
                <div class="col-12">
                    <div class="card my-4">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                            <div
                                class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3 d-flex justify-content-between align-items-center">
                                <h6 class="text-white text-capitalize ps-3">Order History</h6>
                            </div>
                        </div>

                        <div class="card-body px-0 pb-2">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th
                                                class="text-uppercase text-secondary text-sm font-weight-bold opacity-7 text-center">
                                                Order ID</th>
                                            <th
                                                class="text-uppercase text-secondary text-sm font-weight-bold opacity-7 text-center">
                                                Order Date</th>
                                            <th
                                                class="text-uppercase text-secondary text-sm font-weight-bold opacity-7 text-center">
                                                Total Amount</th>
                                            <th
                                                class="text-uppercase text-secondary text-sm font-weight-bold opacity-7 text-center">
                                                Amount Paid</th>
                                            <th
                                                class="text-uppercase text-secondary text-sm font-weight-bold opacity-7 text-center">
                                                Change Amount</th>
                                            <th
                                                class="text-uppercase text-secondary text-sm font-weight-bold opacity-7 text-center">
                                                Products</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($orderHistory as $order): ?>
                                            <tr>
                                                <td class="text-center">
                                                    <p class="text-xs text-secondary mb-0">
                                                        <?php echo $order['order_id']; ?>
                                                    </p>
                                                </td>
                                                <td class="text-center">
                                                    <p class="text-xs text-secondary mb-0">
                                                        <?php echo $order['order_date']; ?>
                                                    </p>
                                                </td>
                                                <td class="text-center">
                                                    <p class="text-xs text-primary mb-0 font-weight-bold">
                                                        <?php echo $order['total_amount']; ?>
                                                    </p>
                                                </td>
                                                <td class="text-center">
                                                    <p class="text-xs text-primary mb-0 font-weight-bold">
                                                        <?php echo $order['amount_paid']; ?>
                                                    </p>
                                                </td>
                                                <td class="text-center">
                                                    <p class="text-xs text-primary mb-0 font-weight-bold">
                                                        <?php echo $order['change_amount']; ?>
                                                    </p>
                                                </td>
                                                <td class="text-center">
                                                    <p class="text-xs text-primary mb-0 font-weight-bold">
                                                        <?php echo $order['products']; ?>
                                                    </p>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>
    <!--   Core JS Files   -->
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/chartjs.min.js"></script>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>


    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/material-dashboard.min.js?v=3.1.0"></script>
</body>

</html>