$(document).ready(function () {
  $.ajax({
    url: "chart1.php",
    type: "GET",
    success: function (data) {
      console.log(data);

      var provinces = [];
      var averagePovertyRates = [];

      for (var i in data) {
        provinces.push(data[i].Province);
        averagePovertyRates.push(data[i].AveragePovertyRate);
      }

      var chartData = {
        labels: provinces,
        datasets: [
          {
            label: "Average Poverty Rate",
            fill: false,
            lineTension: 0.1,
            backgroundColor: "black",
            borderColor: "black",
            pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
            pointHoverBorderColor: "black",
            data: averagePovertyRates,
          },
        ],
      };

      var ctx = $("#mycanvas1");

      var lineGraph = new Chart(ctx, {
        type: "line",
        data: chartData,
      });
    },
    error: function (data) {},
  });
});
